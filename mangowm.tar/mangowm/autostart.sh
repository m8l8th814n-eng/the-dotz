#!/bin/bash

set +e

wl-clip-persist --clipboard regular --reconnect-tries 0 >/dev/null 2>&1 &
wl-paste --type text --watch cliphist store >/dev/null 2>&1 &
/usr/lib/xdg-desktop-portal-wlr  >/dev/null 2>&1 &

echo "Xft.dpi: 140" | xrdb -merge #dpi缩放
nm-applet >/dev/null 2>&1 &
blueman-applet >/dev/null 2>&1 &
sway-audio-idle-inhibit >/dev/null 2>&1 &
swayosd-server >/dev/null 2>&1 &

swaybg -i ~/backgrounds/sweet.png 2>&1 &
qs 2>&1 &


wlsunset -T 3501 -t 3500 >/dev/null 2>&1 &
